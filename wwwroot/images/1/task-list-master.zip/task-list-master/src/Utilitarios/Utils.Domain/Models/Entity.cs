﻿
namespace Utils.Domain.Models
{
    public abstract class Entity
    {
        public long Id { get; protected set; }
    }
}
