﻿
namespace TaskList.Domain.BoardContext.Models
{
    public enum TypeTaskStatus
    {
        Active = 1,
        Concluded = 2,
        Removed = 3,
    }
}
