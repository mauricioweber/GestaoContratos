﻿

namespace TaskList.Application.BoardContext.InputModels
{
    public class CreateTaskInputModel
    {
        public string Title { get; set; }

        public string Description { get; set; }
    }
}
