﻿

namespace TaskList.Application.BoardContext.InputModels
{
    public class DeleteTaskInputModel
    {
        public long id { get; set; }
    }
}
